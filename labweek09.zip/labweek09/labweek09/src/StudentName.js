import React, {Component} from 'react'

class StudentName extends Component {
    render() {
        return (
            <div>Justin Yeh {this.props.StudentName}</div>
        )
    }
}

export default StudentName 