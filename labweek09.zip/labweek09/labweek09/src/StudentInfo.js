//React Class 
import React, {Component} from 'react'

class StudentInfo extends Component {
    render() {
        return (
            <div>101400171 {this.props.StudentInfo}</div>
        )
    }
}

export default StudentInfo 

