import React, {Component} from 'react'

class College extends Component {
    render() {
        return (
            <div>George Brown College, Toronto {this.props.College}</div>
        )
    }
}

export default College 